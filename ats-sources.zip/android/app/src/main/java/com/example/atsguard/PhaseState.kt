package com.example.atsguard

/**
 * Shared between GuardService (which owns the network connection and enforces the
 * lock) and MainActivity (which only displays the phase). Same process, so a plain
 * volatile singleton is enough.
 */
object PhaseState {
    @Volatile var phase: String = "LOBBY"

    /** Set by MainActivity while it is on screen. Called from a background thread. */
    @Volatile var onChange: ((String) -> Unit)? = null

    fun isLocked(): Boolean = phase == "TASKS" || phase == "MEETING"
}
