package com.example.atsguard

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

private const val TERMS_TEXT = """A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer.

By continuing, you agree that:
- You're using this with the knowledge and consent of everyone in your lobby.
- You're responsible for complying with the terms of service of Discord, Among Us, and anything else this runs alongside.
- It's provided as-is, with no warranty of any kind.

Your Among Us username is stored only on this device and sent to the host you connect to, so they know who's who. It isn't sent anywhere else."""

// Same palette as the website: black, gray, red.
private val BG = Color.parseColor("#000000")
private val PANEL = Color.parseColor("#141414")
private val FIELD = Color.parseColor("#0E0E0E")
private val BORDER = Color.parseColor("#333333")
private val TEXT = Color.parseColor("#EDEDED")
private val DIM = Color.parseColor("#A6A6A6")
private val FAINT = Color.parseColor("#8A8A8A")
private val RED = Color.parseColor("#D42E1D")
private val RED_SOFT = Color.parseColor("#FF6B5E")

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var usageStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var continueToConnect: Button
    private lateinit var playersText: TextView
    private val phaseButtons = mutableMapOf<String, Button>()
    private var username = ""

    // 0 = setup, 1 = permissions, 2 = join a lobby, 3 = hosting a lobby
    private var screen = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        prefs = getSharedPreferences("ats_guard", Context.MODE_PRIVATE)

        val saved = prefs.getString("username", null)
        if (prefs.getBoolean("accepted_terms", false) && !saved.isNullOrBlank()) {
            username = saved
            showNext()
        } else {
            showSetupScreen()
        }
    }

    // ---------- small styling helpers ----------

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int? = null, radius: Int = 12): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun label(text: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun small(text: String) = label(text.uppercase(), 11f, FAINT).apply {
        typeface = Typeface.MONOSPACE
        setPadding(0, 0, 0, dp(8))
    }

    private fun redButton(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(RED, null, 10)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(10)
        }
    }

    private fun ghostButton(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(TEXT)
        background = rounded(Color.TRANSPARENT, BORDER, 10)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply {
            topMargin = dp(10)
        }
    }

    private fun input(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(FAINT)
        setTextColor(TEXT)
        textSize = 15f
        inputType = InputType.TYPE_CLASS_TEXT
        background = rounded(FIELD, BORDER, 10)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun card(vararg children: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(PANEL, Color.parseColor("#262626"), 14)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
        for (c in children) addView(c)
    }

    private fun header(subtitle: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("A.T.S Guard", 22f, TEXT, true))
            addView(label(subtitle, 12f, DIM))
        })
    }

    private fun page(vararg children: View): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(28))
            for (c in children) addView(c)
        }
        return ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        }
    }

    // ---------- first-run setup ----------

    private fun showSetupScreen() {
        val termsBody = label(TERMS_TEXT, 12f, DIM)
        val termsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(FIELD, BORDER, 10)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(termsBody)
        }

        val usernameInput = input("Your Among Us username")
        val acceptCheck = CheckBox(this).apply {
            text = "I accept the terms and license"
            setTextColor(DIM)
            buttonTintList = android.content.res.ColorStateList.valueOf(RED)
        }
        val continueBtn = redButton("Continue").apply {
            isEnabled = false
            alpha = 0.4f
        }

        fun checkReady() {
            val ready = acceptCheck.isChecked && usernameInput.text.toString().trim().isNotEmpty()
            continueBtn.isEnabled = ready
            continueBtn.alpha = if (ready) 1f else 0.4f
        }
        acceptCheck.setOnCheckedChangeListener { _, _ -> checkReady() }
        usernameInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = checkReady()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        continueBtn.setOnClickListener {
            val name = usernameInput.text.toString().trim()
            prefs.edit()
                .putBoolean("accepted_terms", true)
                .putString("username", name)
                .apply()
            username = name
            showPermissionsScreen()
        }

        screen = 0
        setContentView(
            page(
                header("One quick setup, then you're in."),
                card(small("Among Us username"), usernameInput),
                card(small("Terms & license"), termsBox, acceptCheck),
                continueBtn
            )
        )
    }

    // ---------- screen flow: setup -> permissions -> connect ----------

    private fun bothPermissionsOn(): Boolean = hasUsageAccess() && Settings.canDrawOverlays(this)

    private fun showNext() {
        if (!bothPermissionsOn()) showPermissionsScreen()
        else if (PhaseState.link == "HOSTING") showHostScreen()
        else showConnectScreen()
    }

    // ---------- screen 2: permissions ----------

    private fun showPermissionsScreen() {
        screen = 1
        usageStatus = label("", 13f, DIM)
        overlayStatus = label("", 13f, DIM)
        val usageBtn = ghostButton("Allow usage access")
        val overlayBtn = ghostButton("Allow display over other apps")
        continueToConnect = redButton("Continue")

        usageBtn.setOnClickListener {
            discloseThen(
                "Usage access",
                "A.T.S Guard needs \"Usage access\" for one thing: to see the name of the app " +
                    "that is currently on your screen.\n\n" +
                    "While the host has the game locked, if that app is a voice or chat app on " +
                    "the block list (for example Discord or WhatsApp), A.T.S shows a locked " +
                    "screen and sends you home.\n\n" +
                    "It does not see what is inside any app, your messages or your passwords. " +
                    "App names are not saved and are not sent anywhere.\n\n" +
                    "You can turn this off any time in Settings."
            ) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        overlayBtn.setOnClickListener {
            discloseThen(
                "Display over other apps",
                "A.T.S Guard needs this to show the \"Locked during the game\" screen on top " +
                    "of a blocked app. It is used only while the host has the game locked.\n\n" +
                    "You can turn this off any time in Settings."
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        continueToConnect.setOnClickListener { if (bothPermissionsOn()) showConnectScreen() }

        setContentView(
            page(
                header("Step 1 of 2 · Permissions"),
                card(
                    label("Allow these two things so A.T.S can lock chat apps during a game. " +
                        "Turn each one on in the settings page that opens, then come back.", 13f, DIM),
                ),
                card(small("Usage access"), usageStatus, usageBtn),
                card(small("Display over other apps"), overlayStatus, overlayBtn),
                continueToConnect
            )
        )
        refreshPermissionStatus()
    }

    // ---------- screen 3: connect ----------

    private fun showConnectScreen() {
        screen = 2
        statusText = label("Guard is off", 18f, TEXT, true)
        val findBtn = redButton("Find my lobby automatically")
        val hostInput = input("Host address (ask your host)").apply {
            setText(prefs.getString("host_ip", "") ?: "")
        }
        val connectBtn = ghostButton("Connect to this address")
        val stopBtn = ghostButton("Stop guard")
        val permsBtn = ghostButton("Check permissions")
        val hostBtn = redButton("Host a lobby on this phone")

        fun startGuard(ip: String) {
            prefs.edit().putString("host_ip", ip).apply()
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            PhaseState.link = "CONNECTING"
            refreshPhase()
            GuardService.start(this, ip)
        }

        findBtn.setOnClickListener {
            statusText.text = "Looking for a lobby on your Wi-Fi..."
            statusText.setTextColor(TEXT)
            findBtn.isEnabled = false
            findBtn.alpha = 0.5f
            Thread {
                val ip = HostFinder.find(this)
                runOnUiThread {
                    findBtn.isEnabled = true
                    findBtn.alpha = 1f
                    if (ip != null) {
                        hostInput.setText(ip)
                        startGuard(ip)
                    } else {
                        statusText.text = "No lobby found. The host must press HOST A LOBBY on their " +
                            "PC, and you must be on the same Wi-Fi. Or type the host's address below."
                        statusText.setTextColor(RED_SOFT)
                    }
                }
            }.start()
        }
        connectBtn.setOnClickListener {
            val ip = hostInput.text.toString().trim()
            if (ip.isNotEmpty()) startGuard(ip)
        }
        stopBtn.setOnClickListener {
            GuardService.stop(this)
            PhaseState.link = "OFF"
            PhaseState.phase = "LOBBY"
            refreshPhase()
        }
        permsBtn.setOnClickListener { showPermissionsScreen() }
        hostBtn.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            PhaseState.link = "CONNECTING"
            PhaseState.phase = "LOBBY"
            GuardService.startHosting(this)
            showHostScreen()
        }

        setContentView(
            page(
                header("Playing as $username"),
                card(small("Status"), statusText),
                card(
                    small("Step 2 of 2 · Join the lobby"),
                    findBtn,
                    label("The host presses HOST A LOBBY in the A.T.S app on their PC. " +
                        "You both need to be on the same Wi-Fi.", 12f, FAINT)
                        .apply { setPadding(0, dp(10), 0, 0) }
                ),
                card(small("Or type the host's address"), hostInput, connectBtn),
                card(
                    small("Or be the host"),
                    hostBtn,
                    label("Other players on your Wi-Fi or your phone's hotspot can find your lobby. " +
                        "It does not work over mobile data.", 12f, FAINT)
                        .apply { setPadding(0, dp(10), 0, 0) }
                ),
                card(stopBtn, permsBtn),
                label(
                    "While the host has the game locked, opening a blocked voice or chat app " +
                        "shows a locked screen and sends you home. It can't mute apps, " +
                        "and it unlocks when the host ends the game. If the connection drops, " +
                        "A.T.S keeps trying to reconnect by itself.",
                    12f, FAINT
                ).apply { setPadding(0, dp(18), 0, 0) }
            )
        )
        refreshPhase()
    }

    // ---------- screen 4: hosting a lobby ----------

    private fun showHostScreen() {
        screen = 3
        statusText = label("Starting your lobby...", 18f, TEXT, true)
        playersText = label("", 13f, DIM)
        phaseButtons.clear()

        fun phaseButton(phase: String, text: String): Button {
            val b = ghostButton(text)
            b.setOnClickListener {
                GuardService.hostServer?.setPhase(phase)
                refreshHost()
            }
            phaseButtons[phase] = b
            return b
        }
        val lobbyBtn = phaseButton("LOBBY", "Lobby: everything open")
        val tasksBtn = phaseButton("TASKS", "Tasks: chat apps locked")
        val meetingBtn = phaseButton("MEETING", "Meeting: chat apps locked")
        val stopBtn = ghostButton("Close the lobby")
        stopBtn.setOnClickListener {
            GuardService.stop(this)
            PhaseState.link = "OFF"
            PhaseState.phase = "LOBBY"
            showConnectScreen()
        }

        val addresses = HostServer.localAddresses()
        val addrText = if (addresses.isEmpty()) "No Wi-Fi or hotspot found. Turn one on, then reopen the lobby."
        else "Players find this lobby automatically. Or they can type: " + addresses.joinToString(", ")

        setContentView(
            page(
                header("Hosting as $username"),
                card(small("Lobby"), statusText, playersText),
                card(
                    small("Set the game phase"),
                    lobbyBtn, tasksBtn, meetingBtn,
                    label("Tasks and Meeting lock every player's chat apps, including yours. " +
                        "Lobby opens everything again. Set Lobby when the game is over.", 12f, FAINT)
                        .apply { setPadding(0, dp(10), 0, 0) }
                ),
                card(small("How players join"), label(addrText, 13f, DIM)),
                card(stopBtn)
            )
        )
        refreshHost()
    }

    private fun refreshHost() {
        if (screen != 3) return
        if (PhaseState.link == "HOST_ERROR") {
            showConnectScreen()
            return
        }
        val phase = PhaseState.phase
        statusText.text = when (PhaseState.link) {
            "HOSTING" -> "Hosting · Phase: $phase"
            "CONNECTING" -> "Starting your lobby..."
            else -> "Lobby is closed"
        }
        statusText.setTextColor(if (PhaseState.isLocked()) RED_SOFT else TEXT)
        playersText.text = "Players connected: ${GuardService.hostServer?.players ?: 0}"
        for ((p, b) in phaseButtons) {
            val selected = p == phase
            b.background = rounded(if (selected) RED else Color.TRANSPARENT, if (selected) null else BORDER, 10)
            b.setTextColor(if (selected) Color.WHITE else TEXT)
        }
    }

    private fun refreshPhase() {
        if (screen == 3) { refreshHost(); return }
        if (screen != 2) return
        val phase = PhaseState.phase
        statusText.text = when (PhaseState.link) {
            "CONNECTING" -> "Connecting to the host..."
            "CONNECTED" -> "Connected · Phase: $phase"
            "RETRYING" ->
                if (PhaseState.lostAt > 0) "Lost the host. Reconnecting..."
                else "Can't reach the host yet. Still trying..."
            "HOST_ERROR" -> "Couldn't start the lobby. Close other apps using it and try again."
            else -> "Guard is off"
        }
        val bad = PhaseState.link == "RETRYING" || PhaseState.link == "HOST_ERROR"
        statusText.setTextColor(if (bad || PhaseState.isLocked()) RED_SOFT else TEXT)
    }

    private fun refreshPermissionStatus() {
        if (screen != 1) return
        val usageOn = hasUsageAccess()
        val overlayOn = Settings.canDrawOverlays(this)
        usageStatus.text = "Usage access: " + if (usageOn) "ON" else "OFF"
        usageStatus.setTextColor(if (usageOn) TEXT else RED_SOFT)
        overlayStatus.text = "Display over other apps: " + if (overlayOn) "ON" else "OFF"
        overlayStatus.setTextColor(if (overlayOn) TEXT else RED_SOFT)
        val ready = usageOn && overlayOn
        continueToConnect.isEnabled = ready
        continueToConnect.alpha = if (ready) 1f else 0.4f
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // Prominent disclosure: shown in the app before the user is sent to system settings,
    // and only continues if the user taps "I agree".
    private fun discloseThen(title: String, message: String, onAgree: () -> Unit) {
        AlertDialog.Builder(this, androidx.appcompat.R.style.Theme_AppCompat_Dialog_Alert)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("I agree") { _, _ -> onAgree() }
            .setNegativeButton("No thanks", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        PhaseState.onChange = { runOnUiThread { refreshPhase() } }
        if (screen == 1) {
            refreshPermissionStatus()
            // Coming back from Settings with both switched on: move straight on.
            if (bothPermissionsOn()) showConnectScreen()
        } else {
            refreshPhase()
        }
    }

    override fun onPause() {
        PhaseState.onChange = null
        super.onPause()
    }
}
