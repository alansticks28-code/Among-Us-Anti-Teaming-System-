plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.atsguard"
    compileSdk = 34

    defaultConfig {
        applicationId = "gg.ats.guard"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("atsVersionCode") as String?)?.toInt() ?: 1
        versionName = "0.1"
    }

    // Release signing is only used when the GitHub build supplies the upload key.
    // Without those values the normal debug build for sideloading works as before.
    val ksFile = project.findProperty("atsKeystore") as String?
    if (ksFile != null) {
        signingConfigs {
            create("upload") {
                storeFile = file(ksFile)
                storePassword = project.findProperty("atsStorePassword") as String?
                keyAlias = project.findProperty("atsKeyAlias") as String?
                keyPassword = project.findProperty("atsKeyPassword") as String?
            }
        }
        buildTypes {
            getByName("release") { signingConfig = signingConfigs.getByName("upload") }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
