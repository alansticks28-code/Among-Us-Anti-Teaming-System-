package com.example.atsguard

/**
 * Best-effort, unverified list of package names for common voice/IM apps.
 * These are public identifiers (not secrets), but app publishers do
 * occasionally change them across major rewrites — treat this as a
 * starting point to check against the current Play Store listing, not
 * a guaranteed-current source of truth.
 */
object TargetApps {
    val PACKAGES: Set<String> = setOf(
        "com.discord",
        "com.whatsapp",
        "org.telegram.messenger",
        "com.facebook.orca",       // Messenger
        "com.skype.raider",
        "us.zoom.videomeetings",
        "com.microsoft.teams",
        "com.Slack",
        "com.viber.voip",
        "org.thoughtcrime.securesms", // Signal
    )
}
