package com.example.atsguard

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/**
 * When a Wi-Fi network has no internet (a phone hotspot, a router with no data), Android
 * quietly sends this app's traffic over mobile data instead, so a lobby on the Wi-Fi can
 * never be reached. Binding the app to the Wi-Fi network fixes that.
 */
object NetworkBinder {
    fun bindToWifi(context: Context) {
        try {
            val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (net in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(net) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(net)
                    return
                }
            }
        } catch (_: Exception) {}
    }

    fun unbind(context: Context) {
        try {
            val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.bindProcessToNetwork(null)
        } catch (_: Exception) {}
    }
}
