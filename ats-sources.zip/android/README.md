# A.T.S Guard for Android

Locks voice and chat apps on your phone while the host's Among Us game is locked.

## How it works

Android does not let one app mute another, so A.T.S does not try to. Instead:

1. You connect to the host (same host as the desktop app, port 8765).
2. A small foreground service checks which app is on screen (needs **Usage access**).
3. While the host has the game locked (TASKS or MEETING), opening an app on the block list
   (`TargetApps.kt`) shows a black "Locked during the game" screen over it (needs
   **Display over other apps**) and sends you to the home screen.
4. When the host ends the game, or the connection drops, the lock lifts.

There is no Accessibility Service. Google blocks Accessibility apps installed from a browser
in some countries (including India), which is why this version avoids it.

## Honest status

Written without an Android SDK to compile against, so it has not been run. Expect a small
fix or two on the first build and on-phone test. Package names in `TargetApps.kt` are best guesses.
