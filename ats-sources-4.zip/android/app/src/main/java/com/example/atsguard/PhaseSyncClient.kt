package com.example.atsguard

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Keeps itself connected to the host (same protocol as the desktop app: newline-delimited
 * JSON on TCP port 8765). If the host can't be reached, or the connection drops or goes
 * quiet for 15 seconds (the host pings every 5), it simply tries again every 2 seconds
 * until disconnect() is called.
 */
class PhaseSyncClient(private val hostIp: String, private val onUpdate: () -> Unit) {

    @Volatile private var running = false
    @Volatile private var socket: Socket? = null

    fun connect() {
        running = true
        PhaseState.link = "CONNECTING"
        PhaseState.lostAt = 0L
        Thread { loop() }.start()
    }

    private fun loop() {
        while (running) {
            var wasConnected = false
            try {
                val s = Socket()
                socket = s
                s.connect(InetSocketAddress(hostIp, 8765), 4000)
                s.keepAlive = true
                s.soTimeout = 15_000
                wasConnected = true
                PhaseState.link = "CONNECTED"
                PhaseState.lostAt = 0L
                onUpdate()
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                while (running) {
                    val line = reader.readLine() ?: break
                    try {
                        val json = JSONObject(line)
                        if (json.has("phase")) {
                            PhaseState.phase = json.getString("phase")
                            onUpdate()
                        }
                    } catch (_: Exception) {
                        // ignore malformed line, keep reading
                    }
                }
            } catch (_: Exception) {
                // fall through to retry
            }
            try { socket?.close() } catch (_: Exception) {}
            if (!running) break
            if (wasConnected && PhaseState.lostAt == 0L) PhaseState.lostAt = System.currentTimeMillis()
            PhaseState.link = "RETRYING"
            onUpdate()
            try { Thread.sleep(2_000) } catch (_: InterruptedException) { break }
        }
    }

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
    }
}
