# A.T.S build kit

Turns the A.T.S source into real installable files, built on GitHub's own machines (free).

| You get | File | Notes |
|---|---|---|
| Windows | `ATS-Guard.exe` | Double-click to run. Windows may show a SmartScreen warning because the file is unsigned: More info, then Run anyway. |
| Linux | `ATS-Guard` | `chmod +x ATS-Guard` then `./ATS-Guard`. Needs `pactl` and `xdotool` installed for mute/minimize. |
| macOS | `ATS-Guard-macOS.zip` | Unzip, right-click the app, Open. Detects apps and syncs; per-app muting is not implemented on Mac. |
| Android | `app-debug.apk` | Sideload onto a phone (allow "install unknown apps"). Then turn on A.T.S under Settings, Accessibility. |
| iOS | none | See below. |

## How to build (about 10 minutes, no coding)

1. Make a free account at github.com, then click **New repository** (name it `ats`, keep it Private).
2. Click **uploading an existing file** and drag in everything from this kit, including the hidden `.github` folder. Easiest way: unzip the kit, open the folder, select all, drag in. Commit.
3. Open the **Actions** tab, click **Build A.T.S for every platform**, then **Run workflow**.
4. Wait for the jobs to finish (5-10 min). Open the finished run and download each file under **Artifacts** at the bottom.

## Windows only, right now, no GitHub

On any Windows PC with Python installed:

```
cd desktop
pip install -r requirements.txt pyinstaller
pyinstaller --onefile --noconsole --name ATS-Guard --hidden-import comtypes --collect-all pycaw ats_local_guard.py
```

Your `.exe` appears in `dist\ATS-Guard.exe`.

## iOS: why there is no file

An iPhone app only installs if it is signed by Apple. That needs a paid Apple Developer account ($99/year), and the Screen Time restriction also needs Apple to approve the Family Controls entitlement. The `ios-compile-check` job only proves the code compiles. Getting it onto an iPhone means opening `ios/` in Xcode on a Mac with your Apple account.

## Honest status

Nothing in this kit has been run. It was written in an environment that could not reach package servers, so the first Actions run may show errors, usually small version or path issues. If a job turns red, open it, copy the red error text, and send it to me to fix.
