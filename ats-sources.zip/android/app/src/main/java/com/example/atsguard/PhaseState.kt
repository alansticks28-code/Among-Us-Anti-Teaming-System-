package com.example.atsguard

/**
 * Shared between MainActivity (which owns the network connection) and
 * ATSAccessibilityService (which reacts to it). Both run in the same
 * process, so a plain volatile singleton is enough here.
 */
object PhaseState {
    @Volatile var phase: String = "LOBBY"

    fun isLocked(): Boolean = phase == "TASKS" || phase == "MEETING"
}
