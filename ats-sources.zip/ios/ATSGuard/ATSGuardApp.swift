// ATSGuardApp.swift

import SwiftUI

@main
struct ATSGuardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
