package com.example.atsguard

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

private const val TERMS_TEXT = """A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer.

By continuing, you agree that:
- You're using this with the knowledge and consent of everyone in your lobby.
- You're responsible for complying with the terms of service of Discord, Among Us, and anything else this runs alongside.
- It's provided as-is, with no warranty of any kind.

Your Among Us username is stored only on this device and sent to the host you connect to, so they know who's who. It isn't sent anywhere else."""

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private var mainShown = false
    private lateinit var usageStatus: TextView
    private lateinit var overlayStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ats_guard", Context.MODE_PRIVATE)

        val username = prefs.getString("username", null)
        if (prefs.getBoolean("accepted_terms", false) && !username.isNullOrBlank()) {
            showMainScreen(username)
        } else {
            showSetupScreen()
        }
    }

    private fun showSetupScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "A.T.S — first-time setup"
            textSize = 16f
        }

        val termsScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        termsScroll.addView(TextView(this).apply {
            text = TERMS_TEXT
            textSize = 12f
        })

        val acceptCheck = CheckBox(this).apply { text = "I accept the terms above" }
        val usernameInput = EditText(this).apply { hint = "Among Us username" }
        val continueBtn = Button(this).apply {
            text = "Continue"
            isEnabled = false
        }

        fun checkReady() {
            continueBtn.isEnabled = acceptCheck.isChecked &&
                usernameInput.text.toString().trim().isNotEmpty()
        }

        acceptCheck.setOnCheckedChangeListener { _, _ -> checkReady() }
        usernameInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = checkReady()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        continueBtn.setOnClickListener {
            val name = usernameInput.text.toString().trim()
            prefs.edit()
                .putBoolean("accepted_terms", true)
                .putString("username", name)
                .apply()
            showMainScreen(name)
        }

        root.addView(title)
        root.addView(termsScroll)
        root.addView(acceptCheck)
        root.addView(usernameInput)
        root.addView(continueBtn)
        setContentView(root)
    }

    private fun showMainScreen(username: String) {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "A.T.S Guard"
            textSize = 20f
        }
        val userLabel = TextView(this).apply {
            text = "Playing as: $username"
            textSize = 11f
        }
        statusText = TextView(this).apply {
            text = "Phase: ${PhaseState.phase}"
            textSize = 20f
            setPadding(0, 32, 0, 24)
        }

        val stepsLabel = TextView(this).apply {
            text = "Step 1: allow two permissions"
            textSize = 13f
            setPadding(0, 8, 0, 8)
        }
        usageStatus = TextView(this).apply { textSize = 12f }
        val usageBtn = Button(this).apply { text = "Allow usage access" }
        overlayStatus = TextView(this).apply { textSize = 12f }
        val overlayBtn = Button(this).apply { text = "Allow display over other apps" }

        val connectLabel = TextView(this).apply {
            text = "Step 2: connect to your host"
            textSize = 13f
            setPadding(0, 24, 0, 8)
        }
        val ipInput = EditText(this).apply {
            hint = "Host IP address"
            setText(prefs.getString("host_ip", "") ?: "")
        }
        val connectBtn = Button(this).apply { text = "Connect and start guard" }
        val stopBtn = Button(this).apply { text = "Stop guard" }
        val note = TextView(this).apply {
            text = "While the host has the game locked, opening a blocked voice or chat app " +
                "shows a locked screen and sends you home. It cannot mute apps, " +
                "and it unlocks when the host ends the game."
            textSize = 12f
            setPadding(0, 24, 0, 0)
        }

        connectBtn.setOnClickListener {
            val ip = ipInput.text.toString().trim()
            if (ip.isNotEmpty()) {
                prefs.edit().putString("host_ip", ip).apply()
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                GuardService.start(this, ip)
                statusText.text = "Phase: connecting..."
            }
        }
        stopBtn.setOnClickListener {
            GuardService.stop(this)
            statusText.text = "Phase: LOBBY"
        }
        usageBtn.setOnClickListener {
            discloseThen(
                "Usage access",
                "A.T.S Guard needs \"Usage access\" for one thing: to see the name of the app " +
                    "that is currently on your screen.\n\n" +
                    "While the host has the game locked, if that app is a voice or chat app on " +
                    "the block list (for example Discord or WhatsApp), A.T.S shows a locked " +
                    "screen and sends you home.\n\n" +
                    "It does not see what is inside any app, your messages or your passwords. " +
                    "App names are not saved and are not sent anywhere.\n\n" +
                    "You can turn this off any time in Settings."
            ) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        overlayBtn.setOnClickListener {
            discloseThen(
                "Display over other apps",
                "A.T.S Guard needs this to show the \"Locked during the game\" screen on top " +
                    "of a blocked app. It is used only while the host has the game locked.\n\n" +
                    "You can turn this off any time in Settings."
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        for (v in listOf(title, userLabel, statusText, stepsLabel, usageStatus, usageBtn,
            overlayStatus, overlayBtn, connectLabel, ipInput, connectBtn, stopBtn, note)) {
            root.addView(v)
        }
        setContentView(scroll)
        mainShown = true
        refreshPermissionStatus()
    }

    private fun refreshPermissionStatus() {
        if (!mainShown) return
        usageStatus.text = "Usage access: " + if (hasUsageAccess()) "ON" else "OFF"
        overlayStatus.text = "Display over other apps: " + if (Settings.canDrawOverlays(this)) "ON" else "OFF"
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // Prominent disclosure: shown in the app before the user is sent to system settings,
    // and only continues if the user taps "I agree".
    private fun discloseThen(title: String, message: String, onAgree: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("I agree") { _, _ -> onAgree() }
            .setNegativeButton("No thanks", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
        PhaseState.onChange = { phase ->
            runOnUiThread { if (mainShown) statusText.text = "Phase: $phase" }
        }
        if (mainShown) statusText.text = "Phase: ${PhaseState.phase}"
    }

    override fun onPause() {
        PhaseState.onChange = null
        super.onPause()
    }
}
