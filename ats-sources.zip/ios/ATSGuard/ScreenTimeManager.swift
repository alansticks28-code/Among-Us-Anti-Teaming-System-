// ScreenTimeManager.swift
// UNVERIFIED SCAFFOLD. This is the one legitimate, Apple-sanctioned way
// to restrict specific apps on iOS — the same framework apps like Opal
// or other self-control/focus apps use. It does NOT work just by
// writing this code: it requires Apple to grant your app the "Family
// Controls" entitlement first, and even then only restricts apps the
// USER selects through Apple's own picker UI (you never get to see or
// hardcode which app that is — that's a privacy boundary Apple
// enforces, not a limitation of this code).
//
// The exact shape of ManagedSettings' API has shifted across iOS
// versions — check the current framework headers in Xcode against
// whatever iOS version you're targeting before assuming this compiles
// as-is.

import FamilyControls
import ManagedSettings

final class ScreenTimeManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var selection = FamilyActivitySelection()

    private let store = ManagedSettingsStore()
    private let center = AuthorizationCenter.shared

    func requestAuthorization() {
        Task {
            do {
                try await center.requestAuthorization(for: .individual)
                await MainActor.run { self.isAuthorized = true }
            } catch {
                print("Screen Time authorization failed: \(error)")
            }
        }
    }

    /// Called whenever the phase changes. Shields the user's selected
    /// apps while locked, clears the shield when unlocked.
    func applyLock(_ locked: Bool) {
        store.shield.applications = locked ? selection.applicationTokens : nil
        store.shield.applicationCategories = locked
            ? .specific(selection.categoryTokens)
            : nil
    }
}
