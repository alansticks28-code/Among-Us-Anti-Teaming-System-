package com.example.atsguard

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Connects to the same host as the desktop app (ats_local_guard.py): newline-delimited
 * JSON on TCP port 8765, e.g. {"phase": "LOBBY" | "TASKS" | "MEETING"}.
 *
 * Reports its state through PhaseState.link so the screen can say what is going on.
 * If the connection drops for any reason the phase falls back to LOBBY, so a player is
 * never left locked out without a host.
 */
class PhaseSyncClient(private val hostIp: String, private val onUpdate: () -> Unit) {

    @Volatile private var running = false
    private var socket: Socket? = null

    fun connect() {
        running = true
        PhaseState.link = "CONNECTING"
        Thread {
            var reached = false
            try {
                val s = Socket()
                socket = s
                s.connect(InetSocketAddress(hostIp, 8765), 5000)
                reached = true
                PhaseState.link = "CONNECTED"
                onUpdate()
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                while (running) {
                    val line = reader.readLine() ?: break
                    try {
                        PhaseState.phase = JSONObject(line).getString("phase")
                        onUpdate()
                    } catch (_: Exception) {
                        // ignore malformed line, keep reading
                    }
                }
            } catch (_: Exception) {
                // handled below
            }
            if (running) {
                PhaseState.phase = "LOBBY"
                PhaseState.link = if (reached) "DISCONNECTED" else "FAILED"
                onUpdate()
            }
        }.start()
    }

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
    }
}
