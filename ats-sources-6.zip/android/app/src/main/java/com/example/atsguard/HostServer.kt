package com.example.atsguard

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Lets this phone be the host of a lobby, same protocol as the desktop host:
 *  - TCP 8765: players connect, get the current phase straight away, and get every change.
 *  - A ping every 5 seconds so players know the connection is alive.
 *  - A UDP broadcast on 8766 every 2 seconds so other phones can find the lobby.
 *
 * Works for players on the same Wi-Fi or on the host phone's hotspot. It cannot be reached
 * over mobile data (carriers block incoming connections); that needs an online server.
 */
class HostServer(private val onUpdate: () -> Unit) {

    private val clients = CopyOnWriteArrayList<Socket>()
    private val nameOf = ConcurrentHashMap<Socket, String>()
    @Volatile private var running = false
    private var server: ServerSocket? = null

    val players: Int get() = clients.size

    /** Usernames the connected players have shared. */
    fun names(): List<String> = clients.mapNotNull { nameOf[it] }.filter { it.isNotBlank() }

    fun start(): Boolean {
        return try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(8765))
            server = ss
            running = true
            Thread { acceptLoop(ss) }.start()
            Thread { heartbeatLoop() }.start()
            Thread { beaconLoop() }.start()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        for (c in clients) { try { c.close() } catch (_: Exception) {} }
        clients.clear()
    }

    /** Changes the phase for everyone, including this phone. Safe to call from the UI thread. */
    fun setPhase(phase: String) {
        PhaseState.phase = phase
        onUpdate()
        Thread { sendAll("{\"phase\":\"$phase\"}\n") }.start()
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            try {
                val c = ss.accept()
                c.keepAlive = true
                clients.add(c)
                sendTo(c, "{\"phase\":\"${PhaseState.phase}\"}\n")
                Thread { readLoop(c) }.start()
                onUpdate()
            } catch (_: Exception) {
                if (!running) break
            }
        }
    }

    // Players tell us their username when they join: {"hello": "name"}
    private fun readLoop(c: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(c.getInputStream()))
            while (running) {
                val line = reader.readLine() ?: break
                try {
                    val name = JSONObject(line).optString("hello", "")
                    if (name.isNotBlank()) {
                        nameOf[c] = name.take(20)
                        onUpdate()
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
        }
        nameOf.remove(c)
        clients.remove(c)
        try { c.close() } catch (_: Exception) {}
        onUpdate()
    }

    private fun sendTo(c: Socket, msg: String): Boolean {
        return try {
            val out = c.getOutputStream()
            out.write(msg.toByteArray())
            out.flush()
            true
        } catch (_: Exception) {
            try { c.close() } catch (_: Exception) {}
            clients.remove(c)
            nameOf.remove(c)
            false
        }
    }

    private fun sendAll(msg: String) {
        val before = clients.size
        for (c in clients) sendTo(c, msg)
        if (clients.size != before) onUpdate()
    }

    private fun heartbeatLoop() {
        while (running) {
            try { Thread.sleep(5_000) } catch (_: InterruptedException) { return }
            sendAll("{\"ping\":1}\n")
        }
    }

    private fun beaconLoop() {
        var sock: DatagramSocket? = null
        try {
            sock = DatagramSocket().apply { broadcast = true }
            val msg = "{\"ats\":1,\"port\":8765}".toByteArray()
            while (running) {
                val targets = mutableSetOf<InetAddress>(InetAddress.getByName("255.255.255.255"))
                try {
                    for (ni in NetworkInterface.getNetworkInterfaces()) {
                        for (ia in ni.interfaceAddresses) {
                            ia.broadcast?.let { targets.add(it) }
                        }
                    }
                } catch (_: Exception) {}
                for (t in targets) {
                    try { sock.send(DatagramPacket(msg, msg.size, t, 8766)) } catch (_: Exception) {}
                }
                try { Thread.sleep(2_000) } catch (_: InterruptedException) { break }
            }
        } catch (_: Exception) {
        } finally {
            try { sock?.close() } catch (_: Exception) {}
        }
    }

    companion object {
        /** This phone's addresses on the local network, for players who want to type one in. */
        fun localAddresses(): List<String> {
            val result = mutableListOf<String>()
            try {
                for (ni in NetworkInterface.getNetworkInterfaces()) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (a in ni.inetAddresses) {
                        if (a is Inet4Address && !a.isLoopbackAddress) {
                            a.hostAddress?.let { result.add(it) }
                        }
                    }
                }
            } catch (_: Exception) {}
            return result
        }
    }
}
