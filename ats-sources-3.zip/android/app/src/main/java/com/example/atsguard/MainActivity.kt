package com.example.atsguard

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

private const val TERMS_TEXT = """A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer.

By continuing, you agree that:
- You're using this with the knowledge and consent of everyone in your lobby.
- You're responsible for complying with the terms of service of Discord, Among Us, and anything else this runs alongside.
- It's provided as-is, with no warranty of any kind.

Your Among Us username is stored only on this device and sent to the host you connect to, so they know who's who. It isn't sent anywhere else."""

// Same palette as the website: black, gray, red.
private val BG = Color.parseColor("#000000")
private val PANEL = Color.parseColor("#141414")
private val FIELD = Color.parseColor("#0E0E0E")
private val BORDER = Color.parseColor("#333333")
private val TEXT = Color.parseColor("#EDEDED")
private val DIM = Color.parseColor("#A6A6A6")
private val FAINT = Color.parseColor("#8A8A8A")
private val RED = Color.parseColor("#D42E1D")
private val RED_SOFT = Color.parseColor("#FF6B5E")

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var usageStatus: TextView
    private lateinit var overlayStatus: TextView
    private var mainShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        prefs = getSharedPreferences("ats_guard", Context.MODE_PRIVATE)

        val username = prefs.getString("username", null)
        if (prefs.getBoolean("accepted_terms", false) && !username.isNullOrBlank()) {
            showMainScreen(username)
        } else {
            showSetupScreen()
        }
    }

    // ---------- small styling helpers ----------

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int? = null, radius: Int = 12): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun label(text: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun small(text: String) = label(text.uppercase(), 11f, FAINT).apply {
        typeface = Typeface.MONOSPACE
        setPadding(0, 0, 0, dp(8))
    }

    private fun redButton(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(RED, null, 10)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            topMargin = dp(10)
        }
    }

    private fun ghostButton(text: String) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(TEXT)
        background = rounded(Color.TRANSPARENT, BORDER, 10)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply {
            topMargin = dp(10)
        }
    }

    private fun input(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(FAINT)
        setTextColor(TEXT)
        textSize = 15f
        inputType = InputType.TYPE_CLASS_TEXT
        background = rounded(FIELD, BORDER, 10)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun card(vararg children: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(PANEL, Color.parseColor("#262626"), 14)
        setPadding(dp(18), dp(18), dp(18), dp(18))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
        for (c in children) addView(c)
    }

    private fun header(subtitle: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(ImageView(context).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("A.T.S Guard", 22f, TEXT, true))
            addView(label(subtitle, 12f, DIM))
        })
    }

    private fun page(vararg children: View): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(28))
            for (c in children) addView(c)
        }
        return ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        }
    }

    // ---------- first-run setup ----------

    private fun showSetupScreen() {
        val termsBody = label(TERMS_TEXT, 12f, DIM)
        val termsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(FIELD, BORDER, 10)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(termsBody)
        }

        val usernameInput = input("Your Among Us username")
        val acceptCheck = CheckBox(this).apply {
            text = "I accept the terms and license"
            setTextColor(DIM)
            buttonTintList = android.content.res.ColorStateList.valueOf(RED)
        }
        val continueBtn = redButton("Continue").apply {
            isEnabled = false
            alpha = 0.4f
        }

        fun checkReady() {
            val ready = acceptCheck.isChecked && usernameInput.text.toString().trim().isNotEmpty()
            continueBtn.isEnabled = ready
            continueBtn.alpha = if (ready) 1f else 0.4f
        }
        acceptCheck.setOnCheckedChangeListener { _, _ -> checkReady() }
        usernameInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = checkReady()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        continueBtn.setOnClickListener {
            val name = usernameInput.text.toString().trim()
            prefs.edit()
                .putBoolean("accepted_terms", true)
                .putString("username", name)
                .apply()
            showMainScreen(name)
        }

        setContentView(
            page(
                header("One quick setup, then you're in."),
                card(small("Among Us username"), usernameInput),
                card(small("Terms & license"), termsBox, acceptCheck),
                continueBtn
            )
        )
    }

    // ---------- main screen ----------

    private fun showMainScreen(username: String) {
        statusText = label("Guard is off", 18f, TEXT, true)
        usageStatus = label("", 13f, DIM)
        overlayStatus = label("", 13f, DIM)

        val usageBtn = ghostButton("Allow usage access")
        val overlayBtn = ghostButton("Allow display over other apps")
        val hostInput = input("Host address (ask your host)").apply {
            setText(prefs.getString("host_ip", "") ?: "")
        }
        val connectBtn = redButton("Connect and start guard")
        val stopBtn = ghostButton("Stop guard")

        connectBtn.setOnClickListener {
            val ip = hostInput.text.toString().trim()
            if (ip.isNotEmpty()) {
                prefs.edit().putString("host_ip", ip).apply()
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                if (!hasUsageAccess() || !Settings.canDrawOverlays(this)) {
                    Toast.makeText(
                        this,
                        "Turn both permissions ON above, or A.T.S can't block apps.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                PhaseState.link = "CONNECTING"
                refreshPhase()
                GuardService.start(this, ip)
            }
        }
        stopBtn.setOnClickListener {
            GuardService.stop(this)
            PhaseState.link = "OFF"
            PhaseState.phase = "LOBBY"
            refreshPhase()
        }
        usageBtn.setOnClickListener {
            discloseThen(
                "Usage access",
                "A.T.S Guard needs \"Usage access\" for one thing: to see the name of the app " +
                    "that is currently on your screen.\n\n" +
                    "While the host has the game locked, if that app is a voice or chat app on " +
                    "the block list (for example Discord or WhatsApp), A.T.S shows a locked " +
                    "screen and sends you home.\n\n" +
                    "It does not see what is inside any app, your messages or your passwords. " +
                    "App names are not saved and are not sent anywhere.\n\n" +
                    "You can turn this off any time in Settings."
            ) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        }
        overlayBtn.setOnClickListener {
            discloseThen(
                "Display over other apps",
                "A.T.S Guard needs this to show the \"Locked during the game\" screen on top " +
                    "of a blocked app. It is used only while the host has the game locked.\n\n" +
                    "You can turn this off any time in Settings."
            ) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        setContentView(
            page(
                header("Playing as $username"),
                card(small("Game status"), statusText),
                card(
                    small("Step 1 · Allow two permissions"),
                    usageStatus, usageBtn, overlayStatus, overlayBtn
                ),
                card(small("Step 2 · Connect to your host"), hostInput, connectBtn, stopBtn),
                label(
                    "While the host has the game locked, opening a blocked voice or chat app " +
                        "shows a locked screen and sends you home. It can't mute apps, " +
                        "and it unlocks when the host ends the game.",
                    12f, FAINT
                ).apply { setPadding(0, dp(18), 0, 0) }
            )
        )
        mainShown = true
        refreshPermissionStatus()
        refreshPhase()
    }

    private fun refreshPhase() {
        if (!mainShown) return
        val phase = PhaseState.phase
        statusText.text = when (PhaseState.link) {
            "CONNECTING" -> "Connecting to host..."
            "CONNECTED" -> "Connected · Phase: $phase"
            "FAILED" -> "Could not reach the host. Check the address, and that you are on the same Wi-Fi."
            "DISCONNECTED" -> "Host disconnected. The lock is off."
            else -> "Guard is off"
        }
        val bad = PhaseState.link == "FAILED" || PhaseState.link == "DISCONNECTED"
        statusText.setTextColor(if (bad || PhaseState.isLocked()) RED_SOFT else TEXT)
    }

    private fun refreshPermissionStatus() {
        if (!mainShown) return
        val usageOn = hasUsageAccess()
        val overlayOn = Settings.canDrawOverlays(this)
        usageStatus.text = "Usage access: " + if (usageOn) "ON" else "OFF"
        usageStatus.setTextColor(if (usageOn) TEXT else RED_SOFT)
        overlayStatus.text = "Display over other apps: " + if (overlayOn) "ON" else "OFF"
        overlayStatus.setTextColor(if (overlayOn) TEXT else RED_SOFT)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // Prominent disclosure: shown in the app before the user is sent to system settings,
    // and only continues if the user taps "I agree".
    private fun discloseThen(title: String, message: String, onAgree: () -> Unit) {
        AlertDialog.Builder(this, androidx.appcompat.R.style.Theme_AppCompat_Dialog_Alert)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("I agree") { _, _ -> onAgree() }
            .setNegativeButton("No thanks", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
        PhaseState.onChange = { runOnUiThread { refreshPhase() } }
        refreshPhase()
    }

    override fun onPause() {
        PhaseState.onChange = null
        super.onPause()
    }
}
