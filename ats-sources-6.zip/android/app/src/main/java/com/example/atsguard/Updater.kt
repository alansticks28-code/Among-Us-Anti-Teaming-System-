package com.example.atsguard

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * "Update" button support. The GitHub build publishes ATS-Guard.apk and a tiny version.txt
 * (the build number) to the "latest" release. We compare that number with the installed
 * app's version code, download the APK, and hand it to Android's installer.
 *
 * An update only installs over the current app if both were signed with the same key
 * (see the signing secrets in the GitHub workflow).
 */
object Updater {
    private const val BASE =
        "https://github.com/alansticks28-code/Among-Us-Anti-Teaming-System-/releases/download/latest/"

    @Suppress("DEPRECATION")
    fun installedVersion(ctx: Context): Long {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        return c
    }

    /** Newest build number on GitHub, or null if it can't be read. Call off the main thread. */
    fun latestVersion(): Long? = try {
        val c = open(BASE + "version.txt")
        if (c.responseCode != 200) null
        else c.inputStream.bufferedReader().use { it.readText() }.trim().toLong()
    } catch (_: Exception) {
        null
    }

    /** Downloads the APK into the app's cache. Call off the main thread. */
    fun download(ctx: Context, onProgress: (Int) -> Unit): File? {
        return try {
            val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
            val out = File(dir, "ATS-Guard.apk")
            val c = open(BASE + "ATS-Guard.apk")
            if (c.responseCode != 200) return null
            val total = c.contentLengthLong
            var done = 0L
            c.inputStream.use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            }
            out
        } catch (_: Exception) {
            null
        }
    }

    /** Opens Android's installer. Returns false if the user first has to allow installs from A.T.S. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
