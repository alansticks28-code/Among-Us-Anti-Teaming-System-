package com.example.atsguard

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress

/**
 * Finds a lobby on the same Wi-Fi. The host's desktop app shouts a small UDP message
 * ({"ats":1,"port":8765}) on port 8766 every 2 seconds; we listen for it and return the
 * sender's address. Blocking: call from a background thread.
 */
object HostFinder {
    fun find(context: Context, timeoutMs: Long = 8_000): String? {
        var lock: WifiManager.MulticastLock? = null
        var sock: DatagramSocket? = null
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wm.createMulticastLock("ats:discover").apply {
                setReferenceCounted(false)
                acquire()
            }
            sock = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(8766))
                soTimeout = 1_000
            }
            val buf = ByteArray(256)
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                try {
                    val packet = DatagramPacket(buf, buf.size)
                    sock.receive(packet)
                    val text = String(packet.data, 0, packet.length)
                    if (JSONObject(text).optInt("ats", 0) == 1) {
                        return packet.address.hostAddress
                    }
                } catch (_: java.net.SocketTimeoutException) {
                    // keep listening until the deadline
                } catch (_: Exception) {
                    // not one of ours, ignore
                }
            }
        } catch (_: Exception) {
            // fall through
        } finally {
            try { sock?.close() } catch (_: Exception) {}
            try { lock?.release() } catch (_: Exception) {}
        }
        return null
    }
}
