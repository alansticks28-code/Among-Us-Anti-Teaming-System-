"""
A.T.S — Local Guard (v0.3)
=====================================

Platform status, honestly:
    Windows  — full support: mutes app audio output (pycaw) + minimizes
               windows (pywin32).
    Linux    — full support if you have `pactl` (PulseAudio/PipeWire —
               installed by default on most desktops) and `xdotool`
               (sudo apt install xdotool) for minimizing windows.
    macOS    — detects running apps and stays in sync with the host,
               but per-app audio muting isn't wired up yet: macOS has
               no built-in per-process volume API the way Windows/
               Linux do.
    Android/iOS — see the separate source scaffolds (Accessibility
               Service on Android, Screen Time API on iOS). Neither
               can mute another app's audio — that's an OS sandboxing
               rule, not a gap here.

Phase model:
    LOBBY    -> comms open, free chat. This is the ONLY phase where
                everything reopens — i.e. once the game is actually
                over, not just between meetings.
    TASKS    -> VC/IM apps locked (muted + minimized where supported),
                NO chat at all — same as a normal task phase
    MEETING  -> still locked, quick chat opens for discussion
                the instant the meeting ends, phase drops back to
                TASKS (still locked) and quick chat closes again

One player runs this as HOST. Everyone else runs it and JOINS the
host's IP. When the host changes phase, everyone updates in sync.

Setup:
    pip install -r requirements.txt
    python ats_local_guard.py
"""

import json
import os
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import scrolledtext, simpledialog, messagebox

import psutil

PLATFORM = sys.platform  # 'win32', 'linux', 'darwin'

PYCAW_OK = False
WIN32_OK = False
if PLATFORM == "win32":
    try:
        from pycaw.pycaw import AudioUtilities, ISimpleAudioVolume
        PYCAW_OK = True
    except Exception:
        pass
    try:
        import win32gui
        import win32process
        import win32con
        WIN32_OK = True
    except Exception:
        pass

try:
    import keyboard  # optional, for the F9 hotkey
    KEYBOARD_OK = True
except Exception:
    KEYBOARD_OK = False


TARGET_APPS = [
    "discord", "discordptb", "discordcanary",
    "skype", "zoom", "teams", "slack",
    "whatsapp", "telegram",
    "teamspeak3", "ts3client", "mumble",
    "messenger", "viber", "signal",
]

PHASES = ["LOBBY", "TASKS", "MEETING"]
PHASE_LABEL = {
    "LOBBY": ("comms open — free chat", "#4FE0CB"),
    "TASKS": ("locked — task phase, chat closed", "#FFB238"),
    "MEETING": ("locked — quick chat only", "#FFB238"),
}
TCP_PORT = 8765

CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".ats_guard_config.json")

TERMS_TEXT = """A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer —
treat this as a plain description of how it behaves, not binding
legal terms.

By continuing, you agree that:

  - You're using this with the knowledge and consent of everyone in
    your lobby. It mutes and minimizes other apps on YOUR OWN PC only.
  - You're responsible for complying with the terms of service of
    Discord, Among Us, and anything else this runs alongside.
  - It's provided as-is, with no warranty of any kind. The people who
    built it aren't liable for how you use it or what it does on your
    machine.

Your Among Us username below is stored only in a local config file on
this PC (~/.ats_guard_config.json) and is sent to the host you connect
to, so they know who's who. It isn't sent anywhere else.
"""


def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                data = json.load(f)
            if data.get("accepted_terms") and data.get("username"):
                return data
        except Exception:
            pass
    return None


def save_config(username):
    with open(CONFIG_PATH, "w") as f:
        json.dump({"accepted_terms": True, "username": username}, f)


class SetupWindow(tk.Tk):
    """First-run only: terms acceptance + Among Us username. Skipped on
    every later launch once ~/.ats_guard_config.json exists."""

    def __init__(self, on_complete):
        super().__init__()
        self.on_complete = on_complete
        self.title("A.T.S — Setup")
        self.geometry("440x480")
        self.configure(bg="#0A1416")

        tk.Label(self, text="A.T.S — first-time setup", fg="#4FE0CB", bg="#0A1416",
                 font=("Consolas", 13, "bold")).pack(pady=(18, 10))

        terms_box = scrolledtext.ScrolledText(self, height=14, bg="#102023", fg="#E7F2F1",
                                               font=("Consolas", 9), relief="flat", wrap="word")
        terms_box.insert("1.0", TERMS_TEXT)
        terms_box.config(state="disabled")
        terms_box.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        self.accept_var = tk.BooleanVar(value=False)
        tk.Checkbutton(self, text="I accept the terms above", variable=self.accept_var,
                        fg="#E7F2F1", bg="#0A1416", selectcolor="#102023",
                        activebackground="#0A1416", activeforeground="#E7F2F1",
                        font=("Consolas", 10), command=self._check_ready).pack(anchor="w", padx=16)

        tk.Label(self, text="Among Us username:", fg="#8FA8AB", bg="#0A1416",
                 font=("Consolas", 9)).pack(anchor="w", padx=16, pady=(10, 2))
        self.username_var = tk.StringVar()
        self.username_var.trace_add("write", lambda *_: self._check_ready())
        tk.Entry(self, textvariable=self.username_var, font=("Consolas", 11)).pack(
            fill="x", padx=16)

        self.continue_btn = tk.Button(self, text="Continue", font=("Consolas", 10, "bold"),
                                       bg="#102023", fg="#5C7376", relief="flat",
                                       state="disabled", padx=10, pady=8, command=self._continue)
        self.continue_btn.pack(pady=16)

    def _check_ready(self, *args):
        ready = self.accept_var.get() and self.username_var.get().strip() != ""
        if ready:
            self.continue_btn.config(state="normal", bg="#4FE0CB", fg="#101010")
        else:
            self.continue_btn.config(state="disabled", bg="#102023", fg="#5C7376")

    def _continue(self):
        username = self.username_var.get().strip()
        save_config(username)
        self.destroy()
        self.on_complete(username)


def matching_processes():
    found = {}
    for proc in psutil.process_iter(["pid", "name"]):
        try:
            name = (proc.info["name"] or "").lower()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        for target in TARGET_APPS:
            if name.startswith(target):
                found[proc.info["pid"]] = proc.info["name"]
                break
    return found


def set_output_mute(pid, mute: bool) -> bool:
    if PLATFORM == "win32":
        return _win_mute(pid, mute)
    if PLATFORM.startswith("linux"):
        return _linux_mute(pid, mute)
    return False  # macOS: not implemented yet


def _win_mute(pid, mute):
    if not PYCAW_OK:
        return False
    touched = False
    for session in AudioUtilities.GetAllSessions():
        if session.Process and session.Process.pid == pid:
            volume = session._ctl.QueryInterface(ISimpleAudioVolume)
            volume.SetMute(1 if mute else 0, None)
            touched = True
    return touched


def _linux_mute(pid, mute):
    try:
        out = subprocess.run(["pactl", "list", "sink-inputs"],
                              capture_output=True, text=True, timeout=3).stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    touched = False
    current_index = None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("Sink Input #"):
            current_index = line.split("#", 1)[1]
        elif "application.process.id" in line and current_index is not None:
            if f'"{pid}"' in line:
                subprocess.run(["pactl", "set-sink-input-mute", current_index,
                                 "1" if mute else "0"], capture_output=True)
                touched = True
                current_index = None
    return touched


def minimize_windows_for_pid(pid) -> int:
    if PLATFORM == "win32":
        return _win_minimize(pid)
    if PLATFORM.startswith("linux"):
        return _linux_minimize(pid)
    return 0  # macOS: not implemented yet


def _win_minimize(pid):
    if not WIN32_OK:
        return 0
    count = 0

    def _enum_handler(hwnd, _):
        nonlocal count
        if not win32gui.IsWindowVisible(hwnd):
            return
        _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
        if found_pid == pid:
            win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
            count += 1

    win32gui.EnumWindows(_enum_handler, None)
    return count


def _linux_minimize(pid):
    try:
        subprocess.run(["xdotool", "search", "--pid", str(pid), "windowminimize"],
                        capture_output=True, timeout=3)
        return 1
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return 0


class PhaseServer:
    def __init__(self, log_fn, get_phase=None):
        self.log_fn = log_fn
        self.get_phase = get_phase
        self.clients = []
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("0.0.0.0", TCP_PORT))
        self.sock.listen(8)
        threading.Thread(target=self._accept_loop, daemon=True).start()

    def _accept_loop(self):
        while True:
            try:
                conn, addr = self.sock.accept()
            except OSError:
                return
            self.clients.append(conn)
            self.log_fn(f"Client connected: {addr[0]}")
            # Tell the newcomer the current phase right away, so a phone that joins
            # mid-game locks immediately instead of waiting for the next change.
            if self.get_phase:
                try:
                    conn.sendall((json.dumps({"phase": self.get_phase()}) + "\n").encode())
                except OSError:
                    pass

    def broadcast(self, phase):
        msg = (json.dumps({"phase": phase}) + "\n").encode()
        dead = []
        for c in self.clients:
            try:
                c.sendall(msg)
            except OSError:
                dead.append(c)
        for d in dead:
            self.clients.remove(d)


class PhaseClient:
    def __init__(self, host_ip, on_phase, log_fn):
        self.on_phase = on_phase
        self.log_fn = log_fn
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(5)
        self.sock.connect((host_ip, TCP_PORT))
        self.sock.settimeout(None)
        threading.Thread(target=self._read_loop, daemon=True).start()

    def _read_loop(self):
        buf = b""
        while True:
            try:
                chunk = self.sock.recv(4096)
            except OSError:
                self.log_fn("Disconnected from host.")
                return
            if not chunk:
                self.log_fn("Host closed the connection.")
                return
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                try:
                    data = json.loads(line.decode())
                    self.on_phase(data["phase"])
                except (json.JSONDecodeError, KeyError):
                    pass


def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


class ATSGuardApp:
    def __init__(self, root, username="player"):
        self.root = root
        self.username = username
        self.root.title(f"A.T.S — Local Guard ({username})")
        self.root.geometry("440x520")
        self.root.configure(bg="#0A1416")

        self.phase = "LOBBY"
        self.stop_flag = False
        self.server = None
        self.client = None
        self.is_host = False

        tk.Label(root, text="A.T.S — LOCAL GUARD", fg="#4FE0CB", bg="#0A1416",
                 font=("Consolas", 13, "bold")).pack(pady=(16, 2))
        tk.Label(root, text=f"platform: {PLATFORM}  ·  playing as: {username}", fg="#5C7376", bg="#0A1416",
                 font=("Consolas", 8)).pack(pady=(0, 8))

        self.state_label = tk.Label(root, text=PHASE_LABEL["LOBBY"][0], fg="#4FE0CB",
                                     bg="#0A1416", font=("Consolas", 11))
        self.state_label.pack(pady=(0, 10))

        mode_frame = tk.Frame(root, bg="#0A1416")
        mode_frame.pack(pady=(0, 10))
        tk.Button(mode_frame, text="HOST A LOBBY", font=("Consolas", 10, "bold"),
                  bg="#4FE0CB", fg="#101010", relief="flat", padx=10, pady=6,
                  command=self.start_host).pack(side="left", padx=6)
        tk.Button(mode_frame, text="JOIN A LOBBY", font=("Consolas", 10, "bold"),
                  bg="#FFB238", fg="#101010", relief="flat", padx=10, pady=6,
                  command=self.start_join).pack(side="left", padx=6)

        self.phase_frame = tk.Frame(root, bg="#0A1416")
        self.phase_frame.pack(pady=(4, 12))
        self.phase_buttons = {}
        for p in PHASES:
            b = tk.Button(self.phase_frame, text=p, font=("Consolas", 10, "bold"),
                          bg="#102023", fg="#E7F2F1", relief="flat", padx=12, pady=8,
                          state="disabled", command=lambda ph=p: self.set_phase(ph, broadcast=True))
            b.pack(side="left", padx=4)
            self.phase_buttons[p] = b

        tk.Label(root, text="Detected apps:", fg="#8FA8AB", bg="#0A1416",
                 font=("Consolas", 9)).pack(anchor="w", padx=16)
        self.detected_label = tk.Label(root, text="(scanning...)", fg="#E7F2F1", bg="#0A1416",
                                        font=("Consolas", 9), justify="left", anchor="w")
        self.detected_label.pack(fill="x", padx=16, pady=(0, 10))

        tk.Label(root, text="Log:", fg="#8FA8AB", bg="#0A1416",
                 font=("Consolas", 9)).pack(anchor="w", padx=16)
        self.log = scrolledtext.ScrolledText(root, height=12, bg="#102023", fg="#E7F2F1",
                                              font=("Consolas", 9), relief="flat")
        self.log.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        if PLATFORM == "win32":
            if not PYCAW_OK:
                self._write_log("pycaw not available — output muting disabled. pip install pycaw comtypes")
            if not WIN32_OK:
                self._write_log("pywin32 not available — window minimizing disabled. pip install pywin32")
        elif PLATFORM.startswith("linux"):
            self._write_log("Linux detected — mute needs `pactl`, minimize needs `xdotool` on PATH.")
        elif PLATFORM == "darwin":
            self._write_log("macOS detected — detection + sync work now; mute/minimize coming soon.")

        if KEYBOARD_OK:
            keyboard.add_hotkey("F9", self._cycle_phase)
            self._write_log("Hotkey ready: F9 cycles LOBBY -> TASKS -> MEETING -> TASKS ...")

        threading.Thread(target=self._scan_loop, daemon=True).start()

    def _write_log(self, msg):
        self.log.insert(tk.END, f"[{time.strftime('%H:%M:%S')}] {msg}\n")
        self.log.see(tk.END)

    def _scan_loop(self):
        while not self.stop_flag:
            found = matching_processes()
            text = "\n".join(f"• {n} (pid {p})" for p, n in found.items()) if found else "(none detected)"
            self.detected_label.config(text=text)
            time.sleep(2)

    def start_host(self):
        if self.server or self.client:
            return
        self.is_host = True
        self.server = PhaseServer(self._write_log, lambda: self.phase)
        ip = get_local_ip()
        self._write_log(f"Hosting — teammates join {ip}:{TCP_PORT}")
        for b in self.phase_buttons.values():
            b.config(state="normal")

    def start_join(self):
        if self.server or self.client:
            return
        host_ip = simpledialog.askstring("Join a lobby", "Host's IP address:")
        if not host_ip:
            return
        try:
            self.client = PhaseClient(host_ip, self._on_remote_phase, self._write_log)
            self._write_log(f"Connected to host {host_ip}:{TCP_PORT}. Following their phase changes.")
        except OSError as e:
            messagebox.showerror("Connection failed", f"Couldn't reach {host_ip}:{TCP_PORT}\n{e}")

    def _on_remote_phase(self, phase):
        self.root.after(0, lambda: self.set_phase(phase, broadcast=False))

    def _cycle_phase(self):
        nxt = PHASES[(PHASES.index(self.phase) + 1) % len(PHASES)]
        self.set_phase(nxt, broadcast=self.is_host)

    def set_phase(self, phase, broadcast):
        self.phase = phase
        label, color = PHASE_LABEL[phase]
        self.state_label.config(text=f"{phase} — {label}", fg=color)
        for p, b in self.phase_buttons.items():
            b.config(bg="#1B3336" if p == phase else "#102023")

        lock = phase in ("TASKS", "MEETING")
        found = matching_processes()
        if not found:
            self._write_log(f"Phase -> {phase}. No target apps running.")
        for pid, name in found.items():
            muted = set_output_mute(pid, lock)
            minimized = minimize_windows_for_pid(pid) if lock else 0
            if lock:
                self._write_log(f"Phase -> {phase}. {name}: "
                                 f"{'muted' if muted else 'mute unavailable on this platform'}"
                                 + (f", minimized" if minimized else ""))
            else:
                self._write_log(f"Phase -> {phase}. {name}: restored")

        if broadcast and self.server:
            self.server.broadcast(phase)

    def on_close(self):
        self.stop_flag = True
        self.root.destroy()


def launch_main_app(username):
    root = tk.Tk()
    app = ATSGuardApp(root, username)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()


if __name__ == "__main__":
    config = load_config()
    if config:
        launch_main_app(config["username"])
    else:
        setup = SetupWindow(on_complete=launch_main_app)
        setup.mainloop()
