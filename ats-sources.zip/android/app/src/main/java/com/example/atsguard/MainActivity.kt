package com.example.atsguard

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

private const val TERMS_TEXT = """A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer.

By continuing, you agree that:
- You're using this with the knowledge and consent of everyone in your lobby.
- You're responsible for complying with the terms of service of Discord, Among Us, and anything else this runs alongside.
- It's provided as-is, with no warranty of any kind.

Your Among Us username is stored only on this device and sent to the host you connect to, so they know who's who. It isn't sent anywhere else."""

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private var client: PhaseSyncClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ats_guard", Context.MODE_PRIVATE)

        val username = prefs.getString("username", null)
        if (prefs.getBoolean("accepted_terms", false) && !username.isNullOrBlank()) {
            showMainScreen(username)
        } else {
            showSetupScreen()
        }
    }

    private fun showSetupScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "A.T.S — first-time setup"
            textSize = 16f
        }

        val termsScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        termsScroll.addView(TextView(this).apply {
            text = TERMS_TEXT
            textSize = 12f
        })

        val acceptCheck = CheckBox(this).apply { text = "I accept the terms above" }
        val usernameInput = EditText(this).apply { hint = "Among Us username" }
        val continueBtn = Button(this).apply {
            text = "Continue"
            isEnabled = false
        }

        fun checkReady() {
            continueBtn.isEnabled = acceptCheck.isChecked &&
                usernameInput.text.toString().trim().isNotEmpty()
        }

        acceptCheck.setOnCheckedChangeListener { _, _ -> checkReady() }
        usernameInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = checkReady()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        continueBtn.setOnClickListener {
            val name = usernameInput.text.toString().trim()
            prefs.edit()
                .putBoolean("accepted_terms", true)
                .putString("username", name)
                .apply()
            showMainScreen(name)
        }

        root.addView(title)
        root.addView(termsScroll)
        root.addView(acceptCheck)
        root.addView(usernameInput)
        root.addView(continueBtn)
        setContentView(root)
    }

    private fun showMainScreen(username: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "A.T.S Guard"
            textSize = 16f
        }
        val userLabel = TextView(this).apply {
            text = "Playing as: $username"
            textSize = 11f
        }
        statusText = TextView(this).apply {
            text = "Phase: LOBBY"
            textSize = 20f
            setPadding(0, 32, 0, 24)
        }
        val ipInput = EditText(this).apply { hint = "Host IP address" }
        val connectBtn = Button(this).apply { text = "Connect to host" }
        val a11yBtn = Button(this).apply { text = "Enable Accessibility permission" }
        val note = TextView(this).apply {
            text = "You must grant Accessibility permission for the lock to do anything. " +
                "This app only sends you back to the home screen when a blocked app opens during a locked game; it can't mute them."
            textSize = 12f
            setPadding(0, 24, 0, 0)
        }

        connectBtn.setOnClickListener {
            val ip = ipInput.text.toString().trim()
            if (ip.isNotEmpty()) {
                client?.disconnect()
                client = PhaseSyncClient(ip) { phase ->
                    runOnUiThread { statusText.text = "Phase: $phase" }
                }
                client!!.connect()
            }
        }

        a11yBtn.setOnClickListener { showAccessibilityDisclosure() }

        root.addView(title)
        root.addView(userLabel)
        root.addView(statusText)
        root.addView(ipInput)
        root.addView(connectBtn)
        root.addView(a11yBtn)
        root.addView(note)
        setContentView(root)
    }

    // Required prominent disclosure: shown in the app, before the user is sent to the
    // system Accessibility settings, and only continues if the user taps "I agree".
    private fun showAccessibilityDisclosure() {
        AlertDialog.Builder(this)
            .setTitle("Accessibility permission")
            .setMessage(
                "A.T.S Guard uses Android's Accessibility Service for one thing: to detect " +
                "which app has just opened on your screen.\n\n" +
                "While the host has the game locked, if you open a voice or chat app on the " +
                "block list (for example Discord or WhatsApp), A.T.S sends you back to the " +
                "home screen.\n\n" +
                "It does not read what is on your screen, what you type, your messages or your " +
                "passwords. It only sees the name of the app that opened. Nothing it sees is " +
                "stored or sent anywhere.\n\n" +
                "You can turn this off at any time in Settings, Accessibility."
            )
            .setPositiveButton("I agree") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("No thanks", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        client?.disconnect()
    }
}
