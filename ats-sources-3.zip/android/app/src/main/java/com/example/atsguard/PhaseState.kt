package com.example.atsguard

/**
 * Shared between GuardService (which owns the network connection and enforces the
 * lock) and MainActivity (which only displays it). Same process, so a plain
 * volatile singleton is enough.
 */
object PhaseState {
    @Volatile var phase: String = "LOBBY"

    /** OFF, CONNECTING, CONNECTED, FAILED (never reached the host) or DISCONNECTED (dropped). */
    @Volatile var link: String = "OFF"

    /** Set by MainActivity while it is on screen. Called from a background thread. */
    @Volatile var onChange: (() -> Unit)? = null

    fun isLocked(): Boolean = link == "CONNECTED" && (phase == "TASKS" || phase == "MEETING")
}
