package com.example.atsguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.net.wifi.WifiManager
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Keeps the game lock running. No Accessibility Service needed.
 *
 *  - Holds the connection to the host (so the lock follows the host's phase).
 *  - Every ~0.7s asks Android which app most recently came to the front
 *    (needs the "Usage access" permission the user grants in Settings).
 *  - While the game is locked and that app is on the block list, it covers the screen
 *    with a black "Locked" screen (needs "Display over other apps") and sends the user
 *    to the home screen.
 *
 * It cannot mute other apps. Android does not allow that.
 */
class GuardService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var client: PhaseSyncClient? = null
    private var lobby: HostServer? = null
    private var overlay: View? = null
    private var lastPkg: String? = null
    private var lastCheck = 0L
    private var wifiLock: WifiManager.WifiLock? = null
    private var cpuLock: PowerManager.WakeLock? = null

    private val tick = object : Runnable {
        override fun run() {
            try { checkForeground() } catch (_: Exception) {}
            handler.postDelayed(this, 700)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = buildNotification("Connecting...")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        acquireLocks()
        val ip = intent?.getStringExtra(EXTRA_HOST)
        if (intent?.getBooleanExtra(EXTRA_HOSTING, false) == true) {
            client?.disconnect()
            client = null
            lobby?.stop()
            val hs = HostServer {
                handler.post { onLinkChanged() }
                PhaseState.onChange?.invoke()
            }
            PhaseState.phase = "LOBBY"
            if (hs.start()) {
                lobby = hs
                Companion.hostServer = hs
                PhaseState.link = "HOSTING"
            } else {
                PhaseState.link = "HOST_ERROR"
                PhaseState.onChange?.invoke()
                stopSelf()
            }
        } else if (!ip.isNullOrBlank()) {
            lobby?.stop()
            lobby = null
            Companion.hostServer = null
            client?.disconnect()
            client = PhaseSyncClient(ip) {
                handler.post { onLinkChanged() }
                PhaseState.onChange?.invoke()
            }
            client!!.connect()
        }

        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hideOverlay()
        client?.disconnect()
        lobby?.stop()
        lobby = null
        Companion.hostServer = null
        releaseLocks()
        PhaseState.phase = "LOBBY"
        if (PhaseState.link != "HOST_ERROR") PhaseState.link = "OFF"
        PhaseState.onChange?.invoke()
        super.onDestroy()
    }

    private fun onLinkChanged() {
        when (PhaseState.link) {
            "CONNECTED" -> updateNotification("Connected · Phase: ${PhaseState.phase}")
            "HOSTING" -> updateNotification(
                "Hosting · ${lobby?.players ?: 0} players · Phase: ${PhaseState.phase}"
            )
            "RETRYING" -> updateNotification("Looking for the host... (retrying)")
            else -> updateNotification("Connecting...")
        }
    }

    // Keep Wi-Fi and the CPU awake while guarding, otherwise phones quietly drop the
    // connection to the host when the screen turns off.
    private fun acquireLocks() {
        if (wifiLock == null) {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ats:wifi").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            } catch (_: Exception) {}
        }
        if (cpuLock == null) {
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ats:cpu").apply {
                    setReferenceCounted(false)
                    acquire(6 * 60 * 60 * 1000L)
                }
            } catch (_: Exception) {}
        }
    }

    private fun releaseLocks() {
        try { wifiLock?.release() } catch (_: Exception) {}
        try { cpuLock?.release() } catch (_: Exception) {}
        wifiLock = null
        cpuLock = null
    }

    // ---------- foreground app check ----------

    private fun checkForeground() {
        if (!PhaseState.isLocked()) {
            hideOverlay()
            return
        }
        val pkg = latestForegroundPackage()
        if (pkg != null && TargetApps.PACKAGES.contains(pkg)) showOverlay() else hideOverlay()
    }

    private fun latestForegroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastCheck == 0L) now - 10_000 else lastCheck - 1_000
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = e.packageName
            }
        }
        lastCheck = now
        return lastPkg
    }

    // ---------- blocking screen ----------

    private fun showOverlay() {
        if (overlay != null) return
        goHome()
        if (!Settings.canDrawOverlays(this)) return

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(64, 64, 64, 64)
        }
        box.addView(TextView(this).apply {
            text = "Locked during the game"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(this).apply {
            text = "The host has locked voice and chat apps until the game ends."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 48)
        })
        box.addView(Button(this).apply {
            text = "Back to home screen"
            setOnClickListener { goHome() }
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(box, params)
            overlay = box
        } catch (_: Exception) {
            overlay = null
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
        overlay = null
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "A.T.S Guard", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("A.T.S Guard is running")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    companion object {
        const val EXTRA_HOST = "host"
        const val EXTRA_HOSTING = "hosting"

        /** The lobby this phone is hosting, if any. Same process as the screens, so a plain field works. */
        @Volatile var hostServer: HostServer? = null
        private const val CHANNEL_ID = "ats_guard"
        private const val NOTIF_ID = 1

        fun start(ctx: Context, hostIp: String) {
            val i = Intent(ctx, GuardService::class.java).putExtra(EXTRA_HOST, hostIp)
            ctx.startForegroundService(i)
        }

        fun startHosting(ctx: Context) {
            val i = Intent(ctx, GuardService::class.java).putExtra(EXTRA_HOSTING, true)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, GuardService::class.java))
        }
    }
}
