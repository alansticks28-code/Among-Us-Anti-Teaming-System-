// PhaseSyncClient.swift
// UNVERIFIED SCAFFOLD — written without Xcode, a simulator, or a real
// device to test against. A real starting point, not working code yet.

import Foundation
import Combine
import Network

final class PhaseSyncClient: ObservableObject {
    @Published var phase: String = "LOBBY"
    @Published var connected: Bool = false

    private var connection: NWConnection?
    private var buffer = Data()

    /// Connects to the same host used by the Windows/Linux desktop app
    /// (ats_local_guard.py) on TCP port 8765, reading newline-delimited
    /// JSON: {"phase": "LOBBY" | "TASKS" | "MEETING"}
    func connect(host: String, port: UInt16 = 8765) {
        guard let nwPort = NWEndpoint.Port(rawValue: port) else { return }
        let endpoint = NWEndpoint.Host(host)
        connection = NWConnection(host: endpoint, port: nwPort, using: .tcp)

        connection?.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                self?.connected = (state == .ready)
            }
        }
        connection?.start(queue: .global())
        receive()
    }

    private func receive() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 4096) { [weak self] data, _, isDone, error in
            guard let self = self else { return }
            if let data = data, !data.isEmpty {
                self.buffer.append(data)
                self.processBuffer()
            }
            if error == nil && !isDone {
                self.receive()
            } else {
                DispatchQueue.main.async { self.connected = false }
            }
        }
    }

    private func processBuffer() {
        while let newlineIndex = buffer.firstIndex(of: 0x0A) {
            let line = buffer.subdata(in: buffer.startIndex..<newlineIndex)
            buffer.removeSubrange(buffer.startIndex...newlineIndex)
            if let json = try? JSONSerialization.jsonObject(with: line) as? [String: String],
               let phase = json["phase"] {
                DispatchQueue.main.async { self.phase = phase }
            }
        }
    }

    func disconnect() {
        connection?.cancel()
    }
}
