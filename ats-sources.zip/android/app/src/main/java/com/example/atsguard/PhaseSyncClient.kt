package com.example.atsguard

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket

/**
 * Connects to the exact same host used by the desktop app (ats_local_guard.py):
 * newline-delimited JSON on TCP port 8765, e.g. {"phase": "LOBBY" | "TASKS" | "MEETING"}
 *
 * Runs its read loop on a background thread. If the connection drops for any reason the
 * phase falls back to LOBBY, so a player is never left locked out without a host.
 */
class PhaseSyncClient(private val hostIp: String, private val onPhase: (String) -> Unit) {

    @Volatile private var running = false
    private var socket: Socket? = null

    fun connect() {
        running = true
        Thread {
            try {
                socket = Socket(hostIp, 8765)
                val reader = BufferedReader(InputStreamReader(socket!!.getInputStream()))
                while (running) {
                    val line = reader.readLine() ?: break
                    try {
                        val phase = JSONObject(line).getString("phase")
                        PhaseState.phase = phase
                        onPhase(phase)
                    } catch (_: Exception) {
                        // ignore malformed line, keep reading
                    }
                }
            } catch (_: Exception) {
                // fall through to the cleanup below
            }
            PhaseState.phase = "LOBBY"
            onPhase("DISCONNECTED")
        }.start()
    }

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
    }
}
