package com.example.atsguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * A.T.S Guard accessibility service.
 *
 * Core idea: Android gives third-party apps no way to mute or otherwise
 * control another app's audio — that's a hard sandboxing rule, not a
 * gap in this code. What IS available: an Accessibility Service can see
 * which app just came to the foreground. So instead of muting, this
 * interrupts — the moment a flagged app opens during a locked round, it
 * sends the user straight back to the home screen instead of letting
 * them interact with it.
 *
 * Real limitations to know about:
 *  - This requires the user to manually grant Accessibility permission,
 *    which shows a serious-looking system warning (expected — that
 *    permission is powerful, which is exactly why Android gates it).
 *  - Play Store review is strict about apps using this permission for
 *    non-accessibility purposes. Expect this to work fine sideloaded for
 *    a personal group, but to face real friction if you try to publish
 *    it broadly.
 *  - It reacts to a window change already having happened — there's a
 *    brief moment where the flagged app is visible before this fires.
 */
class ATSAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        if (PhaseState.isLocked() && TargetApps.PACKAGES.contains(pkg)) {
            Toast.makeText(this, "Locked during round — back to the game", Toast.LENGTH_SHORT).show()
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() {}
}
