package com.example.atsguard

/**
 * Shared between GuardService (which owns the network connection and enforces the
 * lock) and MainActivity (which only displays it). Same process, so a plain
 * volatile singleton is enough.
 */
object PhaseState {
    @Volatile var phase: String = "LOBBY"

    /** OFF, CONNECTING, CONNECTED, RETRYING, HOSTING (this phone is the host) or HOST_ERROR. */
    @Volatile var link: String = "OFF"

    /** When we lost a connection that had been working (0 = not lost). */
    @Volatile var lostAt: Long = 0L

    /** Set by MainActivity while it is on screen. Called from a background thread. */
    @Volatile var onChange: (() -> Unit)? = null

    /** A brief Wi-Fi blip should not unlock the game, so the lock holds this long without the host. */
    const val GRACE_MS = 30_000L

    fun isLocked(): Boolean {
        val hostOk = link == "CONNECTED" || link == "HOSTING" ||
            (link == "RETRYING" && lostAt > 0 && System.currentTimeMillis() - lostAt < GRACE_MS)
        return hostOk && (phase == "TASKS" || phase == "MEETING")
    }
}
