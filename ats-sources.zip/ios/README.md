# A.T.S — iOS Companion (unverified scaffold)

## What this actually is

Source code only. I don't have Xcode, a Mac, a simulator, or a real
device available to me, so none of this has been compiled or run.
Treat it as a real starting point, not a working deliverable — and
expect a genuinely higher bar to clear than Android before it does
anything at all.

## What it does, honestly

iOS gives third-party apps zero ability to see other apps' running
state or touch their audio — full stop, no workaround exists. The
*only* legitimate way to restrict specific apps on iOS is Apple's own
**Screen Time API** (`FamilyControls` + `ManagedSettings` +
`DeviceActivity`, iOS 16+). This is the same framework self-control/
focus apps use to let a user block their own distracting apps. It is
Apple-sanctioned, not a workaround — but it comes with real
prerequisites this code alone doesn't satisfy:

1. **Apple has to approve your app for the "Family Controls"
   entitlement.** This isn't a checkbox you flip in Xcode — you
   request it from Apple and they decide whether to grant it. I can't
   predict how long that takes or whether it's approved for this use
   case; check Apple's current developer documentation for the actual
   process, since I can't verify it from here.
2. **The user picks which apps get shielded through Apple's own
   picker UI** (`FamilyActivityPicker`). Your code never sees which
   app that is — Apple deliberately keeps that opaque for privacy.
   You can't hardcode "Discord" — the user has to select it themselves
   each time they want to change the list.
3. You need a **paid Apple Developer Program account** ($99/year) and
   a **real iOS device** — Screen Time APIs behave unreliably or not
   at all in the Simulator.

Until #1 is granted, `ScreenTimeManager.swift` compiles and runs but
`applyLock()` won't actually restrict anything on the device.

## To actually build this

1. Install Xcode (macOS only).
2. Create a new iOS App project named `ATSGuard`, SwiftUI interface.
3. Replace the generated files with the ones in this folder.
4. In Signing & Capabilities, add the Family Controls capability —
   this requires the entitlement request above to have been granted
   for your Apple Developer account/app.
5. Build to a real device (not the Simulator) and test.

If you don't want to go through Apple's entitlement process right
now, the app still runs and shows the live phase from the host over
the network — it just won't be able to shield anything yet.
