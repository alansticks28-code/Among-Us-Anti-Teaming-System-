// ContentView.swift
// UNVERIFIED SCAFFOLD — untested SwiftUI wiring.

import SwiftUI
import FamilyControls

private let termsText = """
A.T.S — Terms of Use (plain-language, v1)

This is a community tool, not a legal document drafted by a lawyer.

By continuing, you agree that:
- You're using this with the knowledge and consent of everyone in your lobby.
- You're responsible for complying with the terms of service of Discord, Among Us, and anything else this runs alongside.
- It's provided as-is, with no warranty of any kind.

Your Among Us username is stored only on this device and sent to the host you connect to, so they know who's who. It isn't sent anywhere else.
"""

struct ContentView: View {
    @AppStorage("ats_accepted_terms") private var acceptedTerms: Bool = false
    @AppStorage("ats_username") private var username: String = ""

    var body: some View {
        if acceptedTerms && !username.isEmpty {
            MainView(username: username)
        } else {
            SetupView(acceptedTerms: $acceptedTerms, username: $username)
        }
    }
}

struct SetupView: View {
    @Binding var acceptedTerms: Bool
    @Binding var username: String
    @State private var accepted = false
    @State private var nameInput = ""

    var body: some View {
        VStack(spacing: 16) {
            Text("A.T.S — first-time setup")
                .font(.headline)

            ScrollView {
                Text(termsText)
                    .font(.footnote)
                    .padding()
            }
            .frame(maxHeight: 260)

            Toggle("I accept the terms above", isOn: $accepted)
                .padding(.horizontal)

            TextField("Among Us username", text: $nameInput)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button("Continue") {
                username = nameInput.trimmingCharacters(in: .whitespaces)
                acceptedTerms = true
            }
            .disabled(!accepted || nameInput.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .padding()
    }
}

struct MainView: View {
    let username: String
    @StateObject private var sync = PhaseSyncClient()
    @StateObject private var screenTime = ScreenTimeManager()
    @State private var hostIP: String = ""
    @State private var showPicker = false

    var body: some View {
        VStack(spacing: 16) {
            Text("A.T.S — iOS Companion (unverified)")
                .font(.headline)

            Text("Playing as: \(username)")
                .font(.caption)
                .foregroundColor(.secondary)

            Text("Phase: \(sync.phase)")
                .font(.title2)

            TextField("Host IP address", text: $hostIP)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)

            Button("Connect to host") {
                sync.connect(host: hostIP)
            }

            Button(screenTime.isAuthorized ? "Screen Time authorized" : "Authorize Screen Time") {
                screenTime.requestAuthorization()
            }
            .disabled(screenTime.isAuthorized)

            Button("Choose apps to shield") {
                showPicker = true
            }
            .familyActivityPicker(isPresented: $showPicker, selection: $screenTime.selection)

            Text("Shielding requires Apple's Family Controls entitlement to be approved for this app first — it does nothing on a normal developer build until then.")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .onChange(of: sync.phase) { newPhase in
            let locked = (newPhase == "TASKS" || newPhase == "MEETING")
            screenTime.applyLock(locked)
        }
    }
}
