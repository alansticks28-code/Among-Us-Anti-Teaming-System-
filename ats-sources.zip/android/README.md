# A.T.S — Android Companion (unverified scaffold)

## What this actually is

This is source code, not an app. I wrote it without an Android SDK,
Gradle, or an emulator available to me — I can't compile it here, so
nothing in this folder has been built or run. Treat it as a real
starting point, not a working deliverable.

## What it does, honestly

Android does not let a third-party app mute or otherwise control
another app's audio — that's a sandboxing rule with no workaround for
a normal (non-rooted) app. So this doesn't try to. Instead it uses an
**Accessibility Service** to detect when a flagged app (Discord,
WhatsApp, etc. — see `TargetApps.kt`) comes to the foreground during a
locked round, and immediately sends the user back to the home screen.
It interrupts, it doesn't silence.

It connects to the same host as the Windows/Linux desktop app
(`ats_local_guard.py`) over the same plain TCP/JSON protocol on port
8765, so phase changes (LOBBY / TASKS / MEETING) sync the same way.

## What it does NOT do

- No enforcement without the user manually granting Accessibility
  permission — a serious system permission with a scary-looking
  warning dialog. That's expected, not a bug.
- Not distributable on the Play Store without real friction: Google
  reviews apps that use Accessibility Service for non-accessibility
  purposes closely, and this would likely need a clear justification
  or get rejected/removed. Fine for sideloading to a private group;
  risky for public distribution as-is.
- Package names in `TargetApps.kt` are current best guesses, not
  verified against today's Play Store listings.

## To actually build this

1. Install Android Studio.
2. Create a new project: **Empty Views Activity**, package name
   `com.example.atsguard` (or update the package name everywhere if
   you pick something else), minimum SDK 26+.
3. Replace the generated files with the ones in this folder, matching
   the same paths (`app/src/main/...`).
4. Build > Build Bundle(s) / APK(s) > Build APK(s). That's the step
   that actually produces an installable `.apk` — I can't do it for
   you here.
5. Install the APK, open the app, tap "Enable Accessibility
   permission" and turn it on for A.T.S Guard in Settings.
